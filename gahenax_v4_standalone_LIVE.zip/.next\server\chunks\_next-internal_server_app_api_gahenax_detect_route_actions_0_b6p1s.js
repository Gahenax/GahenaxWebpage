module.exports=[1615,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_gahenax_detect_route_actions_0_b6p1s.js.map