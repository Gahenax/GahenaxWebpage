module.exports=[41341,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_gahenax_control_route_actions_0qa0v3~.js.map