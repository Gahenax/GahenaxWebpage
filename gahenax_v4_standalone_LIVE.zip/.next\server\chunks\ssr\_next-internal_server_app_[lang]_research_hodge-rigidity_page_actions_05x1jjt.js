module.exports=[41167,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blang%5D_research_hodge-rigidity_page_actions_05x1jjt.js.map