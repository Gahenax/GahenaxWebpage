var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/gahenax/detect/route.js")
R.c("server/chunks/[root-of-the-server]__0rs2t7f._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_gahenax_detect_route_actions_0_b6p1s.js")
R.m(27361)
module.exports=R.m(27361).exports
