var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/gahenax/control/route.js")
R.c("server/chunks/[root-of-the-server]__0h9ryu5._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_gahenax_control_route_actions_0qa0v3~.js")
R.m(61884)
module.exports=R.m(61884).exports
